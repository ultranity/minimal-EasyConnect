#!/bin/sh

PATH=$PATH:/usr/local/bin

logfile=/usr/share/sangfor/EasyConnect/resources/logs/autologin.log
echo "latest auto login time: `date`" > $logfile

easyconn query | grep ' *vpn state *: *Online' > /dev/null 2>&1
if [ $? = 0 ]; then
	echo "already logged in" >> $logfile
	exit 0
fi

easyconn login -t autologin -v >> $logfile 2>&1 </dev/null
