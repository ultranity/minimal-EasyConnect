#!/bin/bash

### BEGIN INIT INFO
# Provides:          EasyConnect
# Required-Start:    $all
# Required-Stop:     $all
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Start or stop the EasyMonitor.
### END INIT INFO

# Starts the at daemon
# Source function library.
RETVAL=0
ECHOME="/usr/share/sangfor/EasyConnect/resources"
PROG=$ECHOME"/bin/EasyMonitor"
PRNAME="EasyMonitor"

start() {
        ${PROG} &
        RETVAL=$?
        return $RETVAL
}

stop() {
	#��kill��ɱ������ʱ��ֱ��ǿ��ɱ��
	killall $PRNAME
	if [ $? -eq 0 ]
	then
		killall -9 $PRNAME
	fi
    RETVAL=$?
    return $RETVAL
}


restart() {
        stop
        start
}

reload() {
        restart
}

case "$1" in
start)
        start
        ;;
stop)
        stop
        ;;
reload|restart)
        restart
        ;;
*)
        echo $"Usage: $0 {start|stop|restart}"
        exit 1
esac

exit $?
exit $RETVAL
