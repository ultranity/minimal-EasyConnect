#!/bin/bash

#####################################
#Writen by: 黄梦良
#
#本脚本功能是错误和日志模块，包含错误号和描述字符串
#映射表，日志输出函数
#
#####################################

#脚本返回错误码
SUCCESS=0	#成功

#提取运行路径
#errlog_self=$(readlink -f $0)
#errlog_script_dir=$(dirname $self)
if [ -z "$LOG_FILE" ]; then
	errlog_script_dir=$(cd "$(dirname "$0")"; pwd)
	errlog_file=$errlog_script_dir/dnsctl.log
else
	errlog_file=$LOG_FILE
fi

echo "log file----->$errlog_file"

#本函数按照一定格式把日志写到文件
write_log() {
    #日志级别
    local level=$1
    #自定义的日志字符串
    local log_str=$2
    #时间
    local current_time=`date '+%Y-%m-%d %H:%M:%S' | tr -d "\n"`
    #完整的一条日志
    local full_log_str="[$current_time] [$level] [dns] $log_str"
    #打印日志到控制台
    echo "$full_log_str"
    #打印日志到日志文件
    echo "$full_log_str" >>$errlog_file
}

#输出info级别日志
logi() {
    local level="INFO"
    local log_str=$1
    write_log "$level" "$log_str"
}

#输出warn级别日志
logw() {
    local level="WARNNING"
    local log_str=$1
    write_log "$level" "$log_str"
}

#输出error级别日志
loge() {
    local level="ERROR"
    local log_str=$1
    write_log "$level" "$log_str"
}

logd() {
    local level="DEBUG"
    local log_str=$1
    write_log "$level" "$log_str"
}
