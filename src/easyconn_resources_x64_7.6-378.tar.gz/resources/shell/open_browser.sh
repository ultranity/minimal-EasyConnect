#!/bin/bash

USER_BROWSER=$1
URL=$2

FIREFOX='firefox'
CHROME='chrome'

CHROME_ARRAY=("chrome" "google-chrome" "google-chrome-stable" "chromium-browser")
#declare -A BROWSER_ARRAYS
#BROWSER_ARRAYS=([1]=（"firefox"） [2]=("chrome" "google-chrome" "google-chrome-stable" "chromium-browser"))

FLAG=0

if [[ "$USER_BROWSER" != "$FIREFOX" &&  "$USER_BROWSER" != "$CHROME" ]]; then 
    FLAG=1
fi

#打开用户使用的浏览器
if [ "$FLAG" -eq 0 ]; then
    echo 'flag equal 0'
    if [ "$USER_BROWSER" = "$FIREFOX" ]; then
        BROWSER_PATH=`which $USER_BROWSER`
        if [ "$BROWSER_PATH" != "" ]; then
            echo "$BROWSER_PATH"
            if [[ -f $BROWSER_PATH && -x $BROWSER_PATH ]]; then
                echo $BROWSER_PATH":"$URL
                $BROWSER_PATH -new-window $URL &
                FLAG=0
            else
                FLAG=1
            fi
        else
            FLAG=1
        fi
    elif [ "$USER_BROWSER" = "$CHROME" ]; then
        for BROWSER_ELE in ${CHROME_ARRAY[@]}; do
            echo $BROWSER_ELE
            BROWSER_PATH=`which $BROWSER_ELE`
            if [ "$BROWSER_PATH" != "" ]; then
                echo "$BROWSER_PATH"
                if [[ -f $BROWSER_PATH && -x $BROWSER_PATH ]]; then
                    echo $BROWSER_PATH":"$URL
                    $BROWSER_PATH -new-window $URL &
                    FLAG=0
                    break;
                else
                    FLAG=1
                fi
            else
                FLAG=1
            fi
        done
    fi
fi

# 打开默认浏览器
if [ "$FLAG" -eq 1 ]; then
    echo $URL
    if [[ -f $BROWSER && -x $BROWSER ]]; then
        echo $BROWSER
        $BROWSER $URL &
    elif which xdg-open > /dev/null; then
        xdg-open "$URL" &
    elif which gnome-open > /dev/null; then
        gnome-open "$URL" &
# elif bla bla bla...
    else
        echo "Could not detect the web browser to use."
    fi
fi
