#!/bin/bash

#vpn的东西都安装在//usr/share/EasyConnect目录下
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/X11/bin:$PATH
export PATH

#程序所在目录
cd `dirname $0`
#ECHOME=$(dirname $(pwd))
#EC客户端的安装目录
ECHOME=/usr/share/sangfor/EasyConnect/resources/
#CSClient文件所在位置
CSCLIENT=$ECHOME/bin/CSClient
#localservice文件所在位置
LOCALSERVICE=$ECHOME/bin/svpnservice

umask u=rwx,g=rwx,o=rwx

#JAVALOCK=/tmp/SangforSSLJava.lock
#if [ ! -f $JAVALOCK ]
#then
#	touch $JAVALOCK
#	chmod 0777 $JAVALOCK
#fi
echo "sslservice.sh start ..."
#env check,envcheck.sh的参数 l3vpn/tcp/vline/none
RETSTR=`/bin/bash $ECHOME/shell/envcheck.sh none`
if [ $? -ne 0 ]; then
	echo "check env failed."
	exit 1
fi

if [ ! -f "$CSCLIENT" ]
then
    echo "$CSCLIENT not exist!"
    exit 1
fi

#启动CSClient程序
#
#先判断CSClient进程是否在运行，如果在运行的话，要杀死，否则新的CSClient的unix域套接字创建不起来
#startup service
if [ ! -f $CSCLIENT ]
then
	echo "$CSCLIENT not exist!"
	exit 1
fi

pidof CSClient
if [ $? -eq 0 ]
then
	killall CSClient
fi
#普通信号杀不死的情况下，是有-9信号
pidof CSClient
if [ $? -eq 0 ]
then
	killall -9 CSClient
fi

params="$@"
let trytimes=10
while [ $trytimes -gt 0 ]
do
    $CSCLIENT  $params &
    if [ $? -eq 0 ]
    then
        let trytimes=0
        echo "start CSClient seccess!"
    else
        let trytimes=$trytimes-1
        echo "start CSClient fail, try again"
        sleep 1
    fi
done

#startup service
if [ ! -f $LOCALSERVICE ]
then
	echo "$LOCALSERVICE not exist!"
	exit 1
fi

#最好检查并杀死当前存在的，防止上次登录的为正常退出
#startup service
pidof svpnservice
if [ $? -eq 0 ]
then
    echo "CSClient is running now, kill it."
    killall svpnservice
    sleep 1
fi
#普通信号杀不死的情况下，是有-9信号
pidof svpnservice
if [ $? -eq 0 ]
then
    echo "kill CSClient fail, try kill -9."
    killall -9 svpnservice
    sleep 1
fi


if [ -u $LOCALSERVICE ] && [ -g $LOCALSERVICE ]
then
	cd $ECHOME/bin/
	let trytimes=10
	while [ $trytimes -gt 0 ]
	do
        #这里必须以守护进程方式运行，否则用户注销之后localservice进程无法正常退出
		$LOCALSERVICE -h $ECHOME &
		if [ $? -eq 0 ]
		then
			let trytimes=0
            echo "start svpnservice seccess!"
			exit 0;
		else
			let trytimes=$trytimes-1
            echo "start svpnservice fail"
			sleep 1
		fi
	done
else
	echo "$localbin not -u"
	exit 1
fi

exit 0

