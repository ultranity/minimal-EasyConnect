#!/bin/bash

MY_DIR=$(cd "$(dirname "$0")"; pwd)


OS_ZBKL="NeoKylin"
OS_UBUNTU="Ubuntu"
RESULT_SUCC=0
RESULT_FAIL=1

SERVICE_NOT_EXIST=0
SERVICE_EXIST=1

SERVICE_MANAGER_UNKNOW=0
SERVICE_MANAGER_SYSTEMCTL=1
SERVICE_MANAGER_SERVICE=2

SERVICE_MANAGER=$SERVICE_MANAGER_UNKNOW

SYSTEM_OS=""
SYSTEM_VERSION=""

CTL_OP=""
PROGRAM_NAME=""
PROGRAM_PATH=""
SERVICE_NAME=""


LOG_DIR=$MY_DIR/../logs
if [ ! -e "$LOG_DIR" ]; then
	mkdir -p $LOG_DIR
fi

LOG_FILE=$LOG_DIR/dnsctl.log
touch $LOG_FILE

LOG_FILE_SIZE=`du -m $LOG_FILE | awk '{print $1}'`

if [ -z "$LOG_FILE_SIZE" ]; then
LOG_FILE_SIZE=0
fi

echo "log file----->$LOG_FILE ----> size:$LOG_FILE_SIZE (M)"

if [ $LOG_FILE_SIZE -ge 5 ]; then
    cp -rp $LOG_FILE $LOG_FILE.bak
    rm -f $LOG_FILE
    touch $LOG_FILE
fi

source $MY_DIR/logout.sh


init_env(){
	#lsb_release -a
	#linux发行版名称
	if [[ -f /usr/bin/lsb_release ]]; then 
		OS=$(/usr/bin/lsb_release -a |grep -i "Description:" |awk -F : '{print $2}' |sed 's/^[ \t]*//g')
		SYSTEM_VERSION=$(/usr/bin/lsb_release -a |grep -i "Release:" |awk -F : '{print $2}' |sed 's/^[ \t]*//g')
	else 
		OS=$(cat /etc/issue |sed -n '1p') 
	fi
}

find_service(){
	pname=$1
	path=$2
	service_name=$pname  #TODO
	service_exist=$SERVICE_NOT_EXIST
	
	#ubuntu >=15 NeoKylin  systemctl; other service
	#systemctl status dbus |grep -v "grep" |grep -i "loaded:.*loaded.*dbus.service"
	systemctl status $service_name |grep -v "grep" |grep -i "Loaded:.*loaded.*$service_name.service"
	if [ $? == 0 ]; then
		logi "find service with systemctl"
	    SERVICE_MANAGER=$SERVICE_MANAGER_SYSTEMCTL
	else
		service $service_name status
		if [ $? == 0 ]; then
			logi "find service with service"
	        SERVICE_MANAGER=$SERVICE_MANAGER_SERVICE
		else
			logi "not find service for $pname"
			SERVICE_MANAGER=$SERVICE_MANAGER_UNKNOW
		fi
	fi
	
	if [ $SERVICE_MANAGER != $SERVICE_MANAGER_UNKNOW ]; then
		SERVICE_NAME=$service_name
		service_exist=$SERVICE_EXIST
	else
		SERVICE_NAME=""
		service_exist=$SERVICE_NOT_EXIST
	fi
	logi "service name ($SERVICE_NAME)"
	return $service_exist
}

start_service(){
	service_name=$1
	result=127
	logi "prepare start service:$service_name"
	if [ $SERVICE_MANAGER == $SERVICE_MANAGER_SYSTEMCTL ]; then
		logi "start service with systemctl"
		systemctl restart $service_name
		result=$?
	elif [ $SERVICE_MANAGER == $SERVICE_MANAGER_SERVICE ]; then
		logi "start service with service"
		service  $service_name start
		result=$?
	else
		logi "not find service ctl"
	fi
	logi "start service:$service_name result=$result"
	return $result
}

stop_service(){
	service_name=$1
	result=127
	logi "prepare stop service:$service_name"
	if [ $SERVICE_MANAGER == $SERVICE_MANAGER_SYSTEMCTL ]; then
		logi "stop service with systemctl"
		systemctl stop $service_name
		result=$?
	elif [ $SERVICE_MANAGER == $SERVICE_MANAGER_SERVICE ]; then
		logi "stop service with service"
		service  $service_name stop
		result=$?
	else
		logi "not found service ctl"
	fi
	logi "stop service:$service_name result=$result"
	return $result
}

flush_interface(){
#ifconfig | cut -d' ' -f1 | sed '/^$/d'
#ifconfig | cut -d' ' -f1 | sed '/^$/d'|	while read line;do echo $line ;ip addr flush $line;done
#ip link show |grep "UP,"|awk -F": " '{print $2}'
#cat /proc/net/dev |grep ":"| grep -v "grep" |awk -F":" '{print $1}'
#ip addr flush xxx
#ip link set xx down|up
	
	logi "list interface:try ip link"
	iflist=(`ip link show |grep "UP,"|awk -F": " '{print $2}'`)
	iflen=${#iflist[@]}
	
	if [ $iflen == 0 ]; then
		logi "try /proc/net/dev"
		iflist=(`cat /proc/net/dev |grep ":"| grep -v "grep" |awk -F":" '{print $1}'`)
		iflen=${#iflist[@]}
	fi
	
	if [ $iflen == 0 ]; then
		logi "list interface:try ifconfig"
		iflist=(`ifconfig | cut -d' ' -f1 | sed '/^$/d'`)
		iflen=${#iflist[@]}
	fi
	
	if [ $iflen == 0 ]; then
		logi "list interface:not find network interface"
	fi
	
	logi "list interface: interface size is $iflen"
	
	for v in ${iflist[@]}; do
		if [ $v != "lo" ] && [ $v != "LO" ]; then
			logi "network interface: flush:$v"
			ip addr flush $v
		fi
	done
}

restart_network_manager(){
#service network-manager restart
#systemctl restart NetworkManager
	result=127
	logi "restart NetworkManager..."
	systemctl restart NetworkManager
	if [ $? != 0 ]; then
		logi "systemctl restart NetworkManager failed!try restart network-manager"
	    service network-manager restart
	fi
	result=$?
	logi "restart NetworkManager... over!result=$result"
	return $result
}


#####main
if [ $# -lt 2 ]; then
	echo "./dns_service_ctl.sh start|stop <program> [program_path] "
	exit 2
fi


CTL_OP=$1
PROGRAM_NAME=$2
PROGRAM_PATH=$3

if [ "start" != $CTL_OP ] && [ "stop" != $CTL_OP ] ; then
	echo "./dns_service_ctl.sh start|stop <program> [program_path] "
	exit $RESULT_FAIL
fi


if [ -z "$PROGRAM_PATH" ]; then
        PROGRAM_PATH=$PROGRAM_NAME
fi
params="$@"
logi "**************************************************************************"
logi "running args ($params)"
find_service $PROGRAM_NAME $PROGRAM_PATH

if [ $? == $SERVICE_EXIST ]  ; then 
	logi "$PROGRAM_NAME 's service exist ($SERVICE_NAME)"
	if [ $SERVICE_NAME == "" ] ; then
		logw "not found $PROGRAM_NAME 's service ;exit"
		exit $RESULT_FAIL
	fi
	if [ "start" == $CTL_OP ] ; then
		chmod +x $PROGRAM_PATH
		logi "try start service ($SERVICE_NAME)"
		start_service $SERVICE_NAME
		exit $?
	fi
	if [ "stop" == $CTL_OP ] ; then
		chmod +x $PROGRAM_PATH
		logi "try stop service ($SERVICE_NAME)"
		stop_service $SERVICE_NAME
		exit $?
	fi
else
	logi "$PROGRAM_NAME 's service not exist!"
	if [ "stop" == $CTL_OP ] ; then
		logw "not found service,could not stop $PROGRAM_NAME"
		exit $RESULT_FAIL
	fi
	cat /etc/NetworkManager/NetworkManager.conf |grep dns=$PROGRAM_NAME
	if [ $? == 0 ]  ; then 
		logi "$PROGRAM_NAME managed by NetworkManager. try restart NetworkManager"
		chmod +x $PROGRAM_PATH
		flush_interface
		restart_network_manager
		exit $?
	else
		logi "$PROGRAM_NAME not managed by NetworkManager"
		exit $RESULT_FAIL
	fi
fi



