#!/bin/bash

MY_DIR=$(cd "$(dirname "$0")"; pwd)


#####main
if [ $# -lt 1 ]; then
	echo "./list_dns.sh outfile "
	exit 2
fi

OUT_FILE=$1
echo "#list dns...$(date)" >$OUT_FILE

#Ubuntu >=16 ,NeoKylin 7
nmcli device show |grep IP4.DNS |awk '{print "dns="$2}' >>$OUT_FILE
#NeoKylin 6
nmcli device list |grep IP4.DNS |awk '{print "dns="$2}' >>$OUT_FILE
#Ubuntu
cat /etc/NetworkManager/system-connections/* |grep "dns=" >>$OUT_FILE