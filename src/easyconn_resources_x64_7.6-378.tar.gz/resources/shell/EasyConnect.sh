#!/bin/bash

#vpn的东西都安装在//usr/share/EasyConnect目录下
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/X11/bin:$PATH
export PATH
LOGFILE="/tmp/com.sangfor.ec.script.start.log"

touch $LOGFILE
chmod 777 $LOGFILE
echo "start...." >$LOGFILE
date >$LOGFILE
if [ "$DISPLAY" = "" ]; then
 	echo "no DISPLAY set to default :0" >>$LOGFILE
	export DISPLAY=:0
fi

printenv >>$LOGFILE
#程序所在目录
cd `dirname $0`
#EC客户端的安装目录
ECHOME=/usr/share/sangfor/EasyConnect
#CSClient文件所在位置
EASYCONNECT=$ECHOME/EasyConnect

umask u=rwx,g=rwx,o=rwx

#启动EasyConnect程序
params="$@"
echo "start args:"$params >>$LOGFILE

#杀死之前浏览器拉起的EasyConnect进程
ps aux |grep  $EASYCONNECT |grep ECAgent
if [ $? -eq 0 ]
then
    EC_pid=`ps aux |grep $EASYCONNECT |grep ECAgent |awk  '{print$2}'`
    kill -9 $EC_pid
fi

#firefox "www.sangfor.com/"$USER &
$EASYCONNECT  $params --enable-transparent-visuals --disable-gpu &
#open -a /Applications/EasyConnect.app --args $params &
if [ $? -ne 0 ]
then
echo "start error!" >>$LOGFILE

    exit 1
fi
echo "start over!" >>$LOGFILE
date >>$LOGFILE

exit 0
